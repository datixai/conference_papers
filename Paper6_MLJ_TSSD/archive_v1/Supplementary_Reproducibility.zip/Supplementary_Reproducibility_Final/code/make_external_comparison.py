#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
core=pd.read_csv(ROOT/'code/core200_results.csv')
base=pd.read_csv(ROOT/'code/external_baseline_results.csv',keep_default_na=False)
arms=['covariate','label','concept']
labels=['Covariate','Label','Concept']
methods=['TSSD','BBSD-soft','Classifier-CUSUM','Page-Hinkley']
vals={m:[] for m in methods}
for arm in arms:
 g=core[core.condition==arm]
 vals['TSSD'].append(100*g.detected.mean())
 for m in methods[1:]:
  h=base[(base.condition==arm)&(base.label_rate==0.05)&(base.method==m)]
  vals[m].append(100*h.detected.mean())
x=np.arange(len(arms)); width=.19
fig,ax=plt.subplots(figsize=(8.3,4.5))
for i,meth in enumerate(methods):
 ax.bar(x+(i-1.5)*width,vals[meth],width,label=meth)
ax.set_ylabel('Valid post-change detections (%)')
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylim(0,105); ax.legend(ncol=2,frameon=False)
ax.grid(axis='y',alpha=.22)
fig.tight_layout()
for ext in ['pdf','png']:
 fig.savefig(ROOT/'figures'/f'fig_external_comparison.{ext}',dpi=240,bbox_inches='tight')
plt.close(fig)
