#!/usr/bin/env python3
from __future__ import annotations
import os,sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import pandas as pd
import run_no_shift as m
import run_shift_study as s
OUT=Path(__file__).resolve().parent
_FIXED=None
def _init(fixed):
 global _FIXED; _FIXED=fixed
def _job(seed_cond_rate):
 seed,cond,rate=seed_cond_rate
 return s.monitor_one(seed,cond,rate,_FIXED)
def main():
 cond=sys.argv[1]; rate=float(sys.argv[2]) if len(sys.argv)>2 else 0.05
 fixed=m.prepare_fixed_source(); jobs=[(i,cond,rate) for i in range(1,201)]
 with ProcessPoolExecutor(max_workers=min(4,os.cpu_count() or 1),initializer=_init,initargs=(fixed,)) as pool:
  rows=list(pool.map(_job,jobs,chunksize=2))
 df=pd.DataFrame(rows); out=OUT/f'core200_{cond}_{str(rate).replace(".","p")}.csv'; df.to_csv(out,index=False)
 print(s.summarize(df)); print('WROTE',out)
if __name__=='__main__': main()
