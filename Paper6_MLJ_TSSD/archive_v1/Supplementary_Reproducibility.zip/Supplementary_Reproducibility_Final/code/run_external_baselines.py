#!/usr/bin/env python3
"""External-baseline comparison for TSSD controlled Gaussian streams.

Baselines
1) Rolling BBSD-soft: classifier-output KS tests as in Rabanser et al. (NeurIPS 2019),
   sequentialized with a fixed 50-case rolling target window. The online threshold is
   calibrated on disjoint source-only streams to a 5% horizon false-alarm target;
   an alarm requires strict exceedance to handle tied/discrete calibration statistics.
2) Classifier-CUSUM-GLR: multiclass extension of the classifier-based CUSUM idea of
   Evans & G'Sell (PLOS ONE 2024). Candidate post-shift class priors are fixed on a
   simplex grid; each candidate maintains a CUSUM using the classifier-based label-shift
   likelihood-ratio estimate, and the detector score is the maximum candidate CUSUM.
   Its threshold is calibrated on disjoint source-only streams.
3) Page-Hinkley-loss: the standard Page-Hinkley recurrence applied only to revealed
   predictive log losses. Because labels are sparse, detection begins after five revealed
   labels. Thresholds are calibrated separately at label rates 0.05 and 0.20.

Calibration and evaluation are deliberately separate. These empirically calibrated
operating points are for finite-horizon comparison only and are not presented as
anytime-valid guarantees.
"""
from __future__ import annotations

import json
import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_no_shift as m
import run_shift_study as s

ALPHA = 0.05
WINDOW = 50
BBSD_STEP = 50
CAL_N = 1000
EVAL_NULL_N = 1000
SHIFT_N = 200
CAL_SEED0 = 12000
EPS = 1e-300
PH_DELTA = 0.005
PH_ALPHA = 0.9999
PH_MIN_LABELS = 5
OUT = HERE


def simplex_grid(k: int, units: int = 20, min_units: int = 1) -> np.ndarray:
    if k != 3:
        raise ValueError("This reproducibility script currently uses K=3.")
    rows = []
    for a in range(min_units, units - 2 * min_units + 1):
        for b in range(min_units, units - a - min_units + 1):
            c = units - a - b
            if c >= min_units:
                rows.append((a / units, b / units, c / units))
    q = np.asarray(rows, float)
    # Exclude near-null candidates so the GLR does not spend grid mass on no change.
    keep = np.sum(np.abs(q - m.PI[None, :]), axis=1) >= 0.10
    return q[keep]


def bbsd_trace(p_tgt: np.ndarray, p_source: np.ndarray, window: int = WINDOW) -> np.ndarray:
    """BBSD-soft score: max classwise KS distance at fixed checkpoints.

    With fixed source and target sample sizes, the KS p-value is monotone in the
    KS distance.  We therefore calibrate the maximum distance directly rather
    than repeatedly converting it to a p-value.
    """
    scores = np.zeros(len(p_tgt), float)
    k = p_tgt.shape[1]
    src_sorted = [np.sort(p_source[:, j]) for j in range(k)]
    nsrc = len(p_source)
    i_right = np.arange(1, window + 1, dtype=float) / window
    i_left = np.arange(0, window, dtype=float) / window
    for t in range(window - 1, len(p_tgt), BBSD_STEP):
        recent = p_tgt[t - window + 1 : t + 1]
        ds = []
        for j in range(k):
            b = np.sort(recent[:, j])
            f_src = np.searchsorted(src_sorted[j], b, side="right") / nsrc
            d = max(float(np.max(i_right - f_src)), float(np.max(f_src - i_left)))
            ds.append(d)
        scores[t] = max(ds)
    return scores


def cusum_glr_trace(p_tgt: np.ndarray, q_grid: np.ndarray) -> np.ndarray:
    weights = q_grid / m.PI[None, :]
    state = np.zeros(len(q_grid), float)
    out = np.zeros(len(p_tgt), float)
    for t, p in enumerate(p_tgt):
        lr = weights @ p
        state = np.maximum(0.0, state) + np.log(np.clip(lr, 1e-12, None))
        out[t] = float(np.max(state))
    return out


def ph_trace(p_tgt: np.ndarray, y_tgt: np.ndarray, reveal: np.ndarray) -> np.ndarray:
    # Reproduces the common scikit-multiflow Page-Hinkley recurrence, but records
    # the statistic rather than applying a built-in fixed threshold.
    x_mean = 0.0
    ph_sum = 0.0
    count = 0
    out = np.zeros(len(p_tgt), float)
    last = 0.0
    for t in range(len(p_tgt)):
        if int(reveal[t]) == 1:
            yy = int(y_tgt[t])
            loss = -math.log(max(float(p_tgt[t, yy]), m.LOG_FLOOR))
            count += 1
            x_mean = x_mean + (loss - x_mean) / float(count)
            ph_sum = max(0.0, PH_ALPHA * ph_sum + (loss - x_mean - PH_DELTA))
            if count >= PH_MIN_LABELS:
                last = ph_sum
        out[t] = last
    return out


def first_cross(trace: np.ndarray, threshold: float):
    idx = np.flatnonzero(trace > threshold)
    return int(idx[0] + 1) if len(idx) else None


def calibration_one(seed: int, fixed, q_grid: np.ndarray, rate: float):
    means, x_fit, model, *_ = fixed
    rng = np.random.default_rng(seed)
    x_tgt, y_tgt = m.draw_pairs(rng, m.T, means)
    reveal = rng.binomial(1, rate, size=m.T).astype(int)
    p_tgt = model.predict_proba(x_tgt)
    p_source = model.predict_proba(x_fit)
    bbsd = bbsd_trace(p_tgt, p_source)
    csum = cusum_glr_trace(p_tgt, q_grid)
    ph = ph_trace(p_tgt, y_tgt, reveal)
    return float(np.max(bbsd)), float(np.max(csum)), float(np.max(ph))


def calibrate(fixed, q_grid: np.ndarray):
    vals = {0.05: [], 0.20: []}
    for rate in vals:
        for i in range(CAL_N):
            vals[rate].append(calibration_one(CAL_SEED0 + i + int(rate * 1000), fixed, q_grid, rate))
    # BBSD and CUSUM do not use labels; use the 0.05 calibration set only.
    arr05 = np.asarray(vals[0.05], float)
    thr = {
        "bbsm_soft": float(np.quantile(arr05[:, 0], 1 - ALPHA, method="higher")),
        "classifier_cusum_glr": float(np.quantile(arr05[:, 1], 1 - ALPHA, method="higher")),
        "page_hinkley_loss_005": float(np.quantile(arr05[:, 2], 1 - ALPHA, method="higher")),
    }
    arr20 = np.asarray(vals[0.20], float)
    thr["page_hinkley_loss_020"] = float(np.quantile(arr20[:, 2], 1 - ALPHA, method="higher"))
    return thr, vals


def stream_for(seed: int, condition: str, rate: float, fixed):
    means, x_fit, model, *_ = fixed
    if condition == "null":
        rng = np.random.default_rng(seed)
        x_tgt, y_tgt = m.draw_pairs(rng, m.T, means)
        reveal = rng.binomial(1, rate, size=m.T).astype(int)
    else:
        cond_index = s.CONDITIONS.index((condition, rate)) + 1
        rng = np.random.default_rng(seed + 10007 * cond_index)
        x_tgt, y_tgt = s.make_target(rng, means, condition)
        # Match run_shift_study random-number consumption: it draws source reference
        # before the reveal mask even though these baselines do not use that reference.
        _x_ref, _y_ref = m.draw_pairs(rng, m.T, means)
        reveal = rng.binomial(1, rate, size=m.T).astype(int)
    return x_tgt, y_tgt, reveal, model, x_fit


def evaluate_one(seed: int, condition: str, rate: float, fixed, q_grid, thr):
    x_tgt, y_tgt, reveal, model, x_fit = stream_for(seed, condition, rate, fixed)
    p_tgt = model.predict_proba(x_tgt)
    p_source = model.predict_proba(x_fit)
    traces = {
        "BBSD-soft": bbsd_trace(p_tgt, p_source),
        "Classifier-CUSUM": cusum_glr_trace(p_tgt, q_grid),
        "Page-Hinkley": ph_trace(p_tgt, y_tgt, reveal),
    }
    thresholds = {
        "BBSD-soft": thr["bbsm_soft"],
        "Classifier-CUSUM": thr["classifier_cusum_glr"],
        "Page-Hinkley": thr["page_hinkley_loss_020" if abs(rate - 0.20) < 1e-9 else "page_hinkley_loss_005"],
    }
    rows = []
    for method, tr in traces.items():
        tm = first_cross(tr, thresholds[method])
        if condition == "null":
            pre = False
            det = tm is not None
            post_tm = tm
        else:
            pre = bool(tm is not None and tm - 1 < s.T0)
            det = bool(tm is not None and not pre and tm - 1 >= s.T0)
            post_tm = tm if det else None
        delay = (post_tm - (s.T0 + 1)) if (condition != "null" and post_tm is not None) else np.nan
        rows.append({
            "seed": seed, "condition": condition, "label_rate": rate, "method": method,
            "threshold": thresholds[method], "prechange_alarm": int(pre), "detected": int(det),
            "detect_time": post_tm if post_tm is not None else np.nan, "delay": delay,
            "max_stat": float(np.max(tr)),
        })
    return rows


def main():
    fixed = m.prepare_fixed_source()
    q_grid = simplex_grid(m.K)
    thr, cal = calibrate(fixed, q_grid)
    (OUT / "external_baseline_thresholds.json").write_text(json.dumps({
        **thr,
        "alpha_horizon": ALPHA,
        "calibration_streams_per_rate": CAL_N,
        "bbsm_window": WINDOW,
        "bbsm_step": BBSD_STEP,
        "ph_delta": PH_DELTA,
        "ph_alpha": PH_ALPHA,
        "ph_min_revealed_labels": PH_MIN_LABELS,
        "cusum_prior_grid_size": int(len(q_grid)),
        "calibration_seed0": CAL_SEED0,
    }, indent=2), encoding="utf-8")

    jobs = []
    for rate in (0.05, 0.20):
        for seed in range(1, EVAL_NULL_N + 1):
            jobs.append((seed, "null", rate))
    core_conditions = [("covariate",0.05),("label",0.05),("concept",0.05),("label",0.20),("concept",0.20)]
    for cond, rate in core_conditions:
        for seed in range(1, SHIFT_N + 1):
            jobs.append((seed, cond, rate))

    # These baselines are lightweight; serial execution avoids pickling a fitted model
    # thousands of times and is fast enough for exact reproducibility.
    rows = []
    for seed, cond, rate in jobs:
        rows.extend(evaluate_one(seed, cond, rate, fixed, q_grid, thr))
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "external_baseline_results.csv", index=False)

    lines = ["External baselines, horizon-calibrated to 5% on disjoint source-only streams",
             f"thresholds={json.dumps(thr, sort_keys=True)}"]
    for rate in (0.05, 0.20):
        g = df[(df.condition == "null") & (df.label_rate == rate)]
        for method, h in g.groupby("method"):
            lines.append(f"null rate={rate:.2f} {method}: alarms={int(h.detected.sum())}/{len(h)}")
    for cond, rate in core_conditions:
        g = df[(df.condition == cond) & (df.label_rate == rate)]
        for method, h in g.groupby("method"):
            det = h[h.detected == 1]
            med = float(det.delay.median()) if len(det) else float('nan')
            q1 = float(det.delay.quantile(.25)) if len(det) else float('nan')
            q3 = float(det.delay.quantile(.75)) if len(det) else float('nan')
            lines.append(f"{cond} rate={rate:.2f} {method}: pre={int(h.prechange_alarm.sum())} detected={int(h.detected.sum())}/{len(h)} median_delay={med} IQR=[{q1},{q3}]")
    text = "\n".join(lines) + "\n"
    (OUT / "external_baseline_summary.txt").write_text(text, encoding="utf-8")
    print(text, end="")

if __name__ == "__main__":
    main()
