#!/usr/bin/env python3
"""Reproduce the frozen TSSD clipping constants from source-only streams.

The calibration sample is disjoint from the reported null-study seeds (1..200)
and the shift-study seeds.  Seeds 9000..9019 are used.  For each source-only
stream, the target and fresh-reference raw scores are computed using exactly the
same predictable state updates as monitoring.  The clipping constant for each
witness is the empirical 95th percentile of the absolute raw score pooled over
target and reference cases.  Concept scores are included only when the concept
witness is active (revealed label and at least five prior revealed labels).
"""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import run_no_shift as m

SEEDS = range(9000, 9020)
QUANTILE = 0.95
OUT = Path(__file__).resolve().parent


def main():
    means, x_fit, model, bandwidth, v_fit, g_inv, mean_v = m.prepare_fixed_source()
    vals = {"X": [], "L": [], "C": [], "MMD": []}

    for seed in SEEDS:
        rng = np.random.default_rng(seed)
        x_tgt, y_tgt = m.draw_pairs(rng, m.T, means)
        x_ref, y_ref = m.draw_pairs(rng, m.T, means)
        reveal = rng.binomial(1, m.LABEL_RATE, size=m.T).astype(int)
        p_tgt = model.predict_proba(x_tgt)
        p_ref = model.predict_proba(x_ref)
        src_kernel_mean, src_v_kernel_mean, k_mon = m.build_stream_kernel_cache(
            x_tgt, x_ref, x_fit, bandwidth, v_fit
        )

        q = m.PI.copy()
        confusion = m.empty_confusion()
        probs_hist, r_hist, y_hist, labeled_y = [], [], [], []

        for t in range(m.T):
            q0 = q.copy()
            c0 = confusion.copy()
            rx_t, rx_r = m.covariate_raw_pair(
                t, x_tgt, x_ref, p_tgt, p_ref, x_fit, bandwidth, v_fit,
                g_inv, mean_v, src_kernel_mean, src_v_kernel_mean, k_mon,
            )
            vals["X"].extend((abs(rx_t), abs(rx_r)))

            if t == 0:
                rm_t = rm_r = 0.0
            else:
                start = max(0, t - m.KERNEL_BUFFER)
                h = m.T
                rm_t = float(k_mon[t, start:t].mean() - k_mon[t, h + start:h + t].mean())
                ridx = h + t
                rm_r = float(k_mon[ridx, start:t].mean() - k_mon[ridx, h + start:h + t].mean())
            vals["MMD"].extend((abs(rm_t), abs(rm_r)))

            rl_t = m.raw_label_score(p_tgt[t], int(reveal[t]), int(y_tgt[t]), q0)
            rl_r = m.raw_label_score(p_ref[t], int(reveal[t]), int(y_ref[t]), q0)
            vals["L"].extend((abs(rl_t), abs(rl_r)))

            if reveal[t] == 1 and len(labeled_y) >= m.M_MIN:
                rc_t = m.raw_concept_score(p_tgt[t], int(y_tgt[t]), q0, c0)
                rc_r = m.raw_concept_score(p_ref[t], int(y_ref[t]), q0, c0)
                vals["C"].extend((abs(rc_t), abs(rc_r)))

            probs_hist.append(p_tgt[t].copy())
            r_hist.append(int(reveal[t]))
            y_hist.append(int(y_tgt[t]))
            q = m.estimate_q_em(
                q, np.asarray(probs_hist), np.asarray(r_hist, dtype=int), np.asarray(y_hist, dtype=int)
            )
            if reveal[t] == 1:
                labeled_y.append(int(y_tgt[t]))
                confusion = m.update_confusion(confusion, p_tgt[t], int(y_tgt[t]))

    clips = {k: float(np.quantile(np.asarray(v, dtype=float), QUANTILE)) for k, v in vals.items()}
    payload = {
        "seeds": [min(SEEDS), max(SEEDS)],
        "quantile": QUANTILE,
        "n_raw_scores": {k: len(v) for k, v in vals.items()},
        "clips": clips,
    }
    (OUT / "clip_calibration.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
