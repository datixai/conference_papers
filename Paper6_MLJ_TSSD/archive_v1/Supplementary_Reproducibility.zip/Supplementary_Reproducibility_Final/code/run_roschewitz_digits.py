#!/usr/bin/env python3
"""Roschewitz et al.-style shift-identification pipeline on the common Digits benchmark.
Implements the published identification logic: BBSD+MMD detection, test prevalence estimation,
prevalence-adjusted reference resampling, feature re-test, and output re-test.
The common 64-D standardized digit representation replaces the medical-image SSL encoder.
"""
from __future__ import annotations
import numpy as np, pandas as pd
from pathlib import Path
from scipy.stats import ks_2samp
from sklearn.metrics.pairwise import rbf_kernel
import run_digits_benchmark as d

OUT=Path(__file__).resolve().parent
ALPHA=.05; N_PERM=99; SEEDS=range(1,51)

def mmd2(K,n):
    # biased MMD^2; same statistic under permutations
    return float(K[:n,:n].mean()+K[n:,n:].mean()-2*K[:n,n:].mean())

def mmd_perm_p(x,y,rng,n_perm=N_PERM):
    z=np.vstack([x,y]); n=len(x); m=len(y)
    # median distance on combined batch, robust to zero distances
    sq=((z[:,None,:]-z[None,:,:])**2).sum(2)
    tri=np.sqrt(sq[np.triu_indices(len(z),1)]); bw=float(np.median(tri[tri>0])) if np.any(tri>0) else 1.0
    gamma=1/(2*bw*bw); K=np.exp(-gamma*sq); obs=mmd2(K,n); ge=1
    idx=np.arange(len(z))
    for _ in range(n_perm):
        rng.shuffle(idx); kp=K[np.ix_(idx,idx)]; ge += (mmd2(kp,n) >= obs-1e-15)
    return ge/(n_perm+1)

def bbsd_p(pref,ptest):
    ps=[ks_2samp(pref[:,j],ptest[:,j],alternative='two-sided',mode='auto').pvalue for j in range(pref.shape[1])]
    return min(1.0, min(ps)*pref.shape[1])

def estimate_q_em(probs,pi,iters=100):
    q=pi.copy()
    for _ in range(iters):
        w=probs*(q/pi)[None,:]; w/=np.clip(w.sum(1,keepdims=True),1e-12,None); qn=w.mean(0); qn=np.clip(qn,1e-4,None); qn/=qn.sum()
        if np.max(np.abs(qn-q))<1e-8: break
        q=qn
    return q

def resample_ref(rng,xpool,ypool,q,n):
    yy=rng.choice(len(q),size=n,p=q); xx=np.empty((n,xpool.shape[1])); ys=np.empty(n,int)
    for i,c in enumerate(yy):
        ids=np.flatnonzero(ypool==c); j=rng.choice(ids); xx[i]=xpool[j]; ys[i]=ypool[j]
    return xx,ys

def one(seed,cond,fixed):
    d.patch(fixed); xfit,model,bw,vfit,ginv,mv,xpool,ypool,pi,q=fixed
    rng=np.random.default_rng(seed+41003*{'null':0,'covariate':1,'label':2}[cond])
    # common shifted target: use only post-change batch from the same generator family
    xt,yt=d.make_stream(rng,fixed,cond); xt=xt[d.T0:]; yt=yt[d.T0:]; n=len(xt)
    ir=rng.integers(0,len(ypool),size=n); xr=xpool[ir]; yr=ypool[ir]
    pt=model.predict_proba(xt); pr=model.predict_proba(xr)
    pb=bbds_p=bbd=None
    p_out=bbds_original=bbd_orig=bbds=bbds_p
    p_bbsd=bbds0=bbd0=bbds_original
    p_bbsd=bbds0=bbd0=bbds_original
    p_bbsd=bbds0
    p_bbsd=bbds0
    # dual detection: C output tests + one feature MMD test, Bonferroni over C+1
    raw_ks=[ks_2samp(pr[:,j],pt[:,j]).pvalue for j in range(pt.shape[1])]
    p_mmd=mmd_perm_p(xr,xt,rng)
    detected=(min(raw_ks+[p_mmd])*(pt.shape[1]+1) < ALPHA)
    if not detected: return {'seed':seed,'condition':cond,'detected':0,'name':'none','p_mmd':p_mmd}
    qhat=estimate_q_em(pt,pi)
    xadj,yadj=resample_ref(rng,xpool,ypool,qhat,n); padj=model.predict_proba(xadj)
    p_mmd_adj=mmd_perm_p(xadj,xt,rng)
    # use the same C+1 Bonferroni scale for the feature decision
    feat_p=min(1.0,p_mmd_adj*(pt.shape[1]+1))
    if feat_p >= ALPHA:
        name='label'
    else:
        # covariate is present; test whether output shift disappears after prevalence adjustment
        raw_out=min(raw_ks)*pt.shape[1]
        adj_ks=[ks_2samp(padj[:,j],pt[:,j]).pvalue for j in range(pt.shape[1])]
        adj_out=min(adj_ks)*pt.shape[1]
        name='mixed' if (raw_out < ALPHA and adj_out >= ALPHA) else 'covariate'
    return {'seed':seed,'condition':cond,'detected':1,'name':name,'p_mmd':p_mmd,'p_mmd_adj':p_mmd_adj}

def main():
    fixed=d.setup(); rows=[]
    for cond in ('null','covariate','label'):
        for s in SEEDS: rows.append(one(s,cond,fixed))
    df=pd.DataFrame(rows); df.to_csv(OUT/'roschewitz_digits_results.csv',index=False)
    lines=[]
    for cond in ('null','covariate','label'):
        g=df[df.condition==cond]; det=int(g.detected.sum())
        if cond=='null': lines.append(f'null detected={det}/{len(g)}')
        else:
            correct=int(((g.detected==1)&(g.name==cond)).sum()); mixed=int((g.name=='mixed').sum()); lines.append(f'{cond}: detected={det}/{len(g)} correct={correct} mixed={mixed}')
    text='\n'.join(lines)+'\n'; (OUT/'roschewitz_digits_summary.txt').write_text(text); print(text,end='')
if __name__=='__main__': main()
