#!/usr/bin/env python3
"""Merge the three expanded 200-replicate primary TSSD arms."""
from pathlib import Path
import pandas as pd
import run_shift_study as s
HERE = Path(__file__).resolve().parent
FILES = [
    HERE / 'core200_covariate_0p05.csv',
    HERE / 'core200_label_0p05.csv',
    HERE / 'core200_concept_0p05.csv',
]

def main():
    frames = [pd.read_csv(p) for p in FILES]
    df = pd.concat(frames, ignore_index=True)
    df.to_csv(HERE / 'core200_results.csv', index=False)
    text = s.summarize(df) + '\n'
    (HERE / 'core200_summary.txt').write_text(text, encoding='utf-8')
    print(text, end='')

if __name__ == '__main__':
    main()
