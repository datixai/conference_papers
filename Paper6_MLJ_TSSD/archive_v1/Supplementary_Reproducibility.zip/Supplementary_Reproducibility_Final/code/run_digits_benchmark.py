#!/usr/bin/env python3
"""Higher-dimensional real-data stress benchmark on sklearn Digits (64 features).
Real handwritten digit vectors are used; shifts are controlled so ground truth type is known.
Covariate shift uses a scanner-like contrast/noise corruption, label shift changes class priors
while preserving empirical X|Y, and concept shift permutes labels while preserving X.
"""
from __future__ import annotations
import math, os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np, pandas as pd
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import pairwise_distances
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import run_no_shift as m

OUT=Path(__file__).resolve().parent
T=300; T0=150; LABEL_RATE=0.05; ALPHA=0.05; ALPHA_K=ALPHA/3
CAL_SEEDS=range(9000,9010); NULL_SEEDS=range(1,51); SHIFT_SEEDS=range(1,51)
KERNEL_BUFFER=50
_FIXED=None; _CLIPS=None

def setup():
    d=load_digits(); X=np.asarray(d.data,float)/16.0; y=np.asarray(d.target,int)
    idx=np.arange(len(y)); fit_idx,pool_idx=train_test_split(idx,train_size=.60,stratify=y,random_state=2026)
    scaler=StandardScaler().fit(X[fit_idx]); x_fit=scaler.transform(X[fit_idx]); x_pool=scaler.transform(X[pool_idx]); y_fit=y[fit_idx]; y_pool=y[pool_idx]
    K=len(np.unique(y)); D=x_fit.shape[1]; pi=np.bincount(y_fit,minlength=K).astype(float); pi/=pi.sum()
    m.K,m.D,m.PI,m.T,m.LABEL_RATE,m.KERNEL_BUFFER=K,D,pi,T,LABEL_RATE,KERNEL_BUFFER
    model=LogisticRegression(solver='lbfgs',max_iter=2000,random_state=2026,C=2.0)
    model.fit(x_fit,y_fit)
    # median heuristic on a fixed 600-sample subset to bound memory and fix reproducibility
    rg=np.random.default_rng(2026); jj=rg.choice(len(x_fit),size=min(600,len(x_fit)),replace=False)
    dist=pairwise_distances(x_fit[jj]); tri=dist[np.triu_indices(len(jj),k=1)]; bw=float(np.median(tri))
    p_fit=model.predict_proba(x_fit); v_fit=p_fit[:,:K-1]/pi[:K-1]-1.0; g=(v_fit.T@v_fit)/len(x_fit); g_inv=np.linalg.pinv(g+1e-8*np.eye(K-1)); mean_v=v_fit.mean(0)
    weights=np.ones(K); weights[:3]=12.0; q=pi*weights; q/=q.sum()
    return (x_fit,model,bw,v_fit,g_inv,mean_v,x_pool,y_pool,pi,q)

def patch(fixed):
    x_fit,model,bw,v_fit,g_inv,mean_v,x_pool,y_pool,pi,q=fixed
    m.K=len(pi); m.D=x_fit.shape[1]; m.PI=pi; m.T=T; m.LABEL_RATE=LABEL_RATE; m.KERNEL_BUFFER=KERNEL_BUFFER

def sample_uniform(rng,xp,yp,n):
    ii=rng.integers(0,len(yp),size=n); return xp[ii].copy(),yp[ii].copy()

def sample_label(rng,xp,yp,q,n):
    yy=rng.choice(len(q),size=n,p=q); xx=np.empty((n,xp.shape[1]))
    for j,c in enumerate(yy):
        ids=np.flatnonzero(yp==c); xx[j]=xp[rng.choice(ids)]
    return xx,yy.astype(int)

def make_stream(rng,fixed,cond):
    x_fit,model,bw,v_fit,g_inv,mean_v,xp,yp,pi,q=fixed
    x0,y0=sample_uniform(rng,xp,yp,T0); n=T-T0
    if cond=='null': x1,y1=sample_uniform(rng,xp,yp,n)
    elif cond=='label': x1,y1=sample_label(rng,xp,yp,q,n)
    elif cond=='concept':
        x1,yb=sample_uniform(rng,xp,yp,n); y1=(yb+1)%len(pi)
    elif cond=='covariate':
        x1,y1=sample_uniform(rng,xp,yp,n)
        # scanner-like acquisition corruption in standardized feature space: mild contrast + sensor noise
        x1=1.35*x1 + rng.normal(0,0.45,size=x1.shape)
    else: raise ValueError(cond)
    return np.vstack([x0,x1]),np.concatenate([y0,y1])

def raw_cal(seed,fixed):
    patch(fixed); x_fit,model,bw,v_fit,g_inv,mean_v,xp,yp,pi,q=fixed
    rng=np.random.default_rng(seed); xt,yt=sample_uniform(rng,xp,yp,T); xr,yr=sample_uniform(rng,xp,yp,T); r=rng.binomial(1,LABEL_RATE,size=T).astype(int)
    pt,pr=model.predict_proba(xt),model.predict_proba(xr); sk,sv,km=m.build_stream_kernel_cache(xt,xr,x_fit,bw,v_fit)
    qc=pi.copy(); conf=m.empty_confusion(); ph=[];rh=[];yh=[]; lab=[]; vals={k:[] for k in 'XLC'}
    for t in range(T):
        q0,c0=qc.copy(),conf.copy(); a,b=m.covariate_raw_pair(t,xt,xr,pt,pr,x_fit,bw,v_fit,g_inv,mean_v,sk,sv,km); vals['X'] += [abs(a),abs(b)]
        a=m.raw_label_score(pt[t],int(r[t]),int(yt[t]),q0); b=m.raw_label_score(pr[t],int(r[t]),int(yr[t]),q0); vals['L'] += [abs(a),abs(b)]
        if r[t] and len(lab)>=m.M_MIN:
            a=m.raw_concept_score(pt[t],int(yt[t]),q0,c0); b=m.raw_concept_score(pr[t],int(yr[t]),q0,c0); vals['C'] += [abs(a),abs(b)]
        ph.append(pt[t]);rh.append(int(r[t]));yh.append(int(yt[t])); qc=m.estimate_q_em(qc,np.asarray(ph),np.asarray(rh),np.asarray(yh))
        if r[t]: lab.append(int(yt[t])); conf=m.update_confusion(conf,pt[t],int(yt[t]))
    return vals

def calibrate(fixed):
    pool={k:[] for k in 'XLC'}
    for seed in CAL_SEEDS:
        v=raw_cal(seed,fixed)
        for k in pool: pool[k].extend(v[k])
    return {k:float(np.quantile(np.asarray(v),.95)) for k,v in pool.items()}

def monitor(seed,cond,fixed,clips):
    patch(fixed); x_fit,model,bw,v_fit,g_inv,mean_v,xp,yp,pi,q=fixed
    cidx={'null':0,'covariate':1,'label':2,'concept':3}[cond]; rng=np.random.default_rng(seed+10007*cidx)
    xt,yt=make_stream(rng,fixed,cond); xr,yr=sample_uniform(rng,xp,yp,T); r=rng.binomial(1,LABEL_RATE,size=T).astype(int)
    pt,pr=model.predict_proba(xt),model.predict_proba(xr); sk,sv,km=m.build_stream_kernel_cache(xt,xr,x_fit,bw,v_fit)
    qc=pi.copy(); conf=m.empty_confusion(); ph=[];rh=[];yh=[];lab=[]
    lp={'X':np.zeros(len(m.CAPITAL_LAMBDAS)),'L':np.zeros(len(m.HOEFFDING_LAMBDAS)),'C':np.zeros(len(m.CONCEPT_LAMBDAS))}; lm={k:np.zeros_like(v) for k,v in lp.items()}
    crossing={}; maxlog={'X':0.0,'L':0.0,'C':0.0}; line=math.log(1/ALPHA_K)
    for t in range(T):
        q0,c0=qc.copy(),conf.copy(); a,b=m.covariate_raw_pair(t,xt,xr,pt,pr,x_fit,bw,v_fit,g_inv,mean_v,sk,sv,km); sx1,sx2=m.clipped_score(a,clips['X']),m.clipped_score(b,clips['X'])
        a=m.raw_label_score(pt[t],int(r[t]),int(yt[t]),q0); b=m.raw_label_score(pr[t],int(r[t]),int(yr[t]),q0); sl1,sl2=m.clipped_score(a,clips['L']),m.clipped_score(b,clips['L'])
        if r[t] and len(lab)>=m.M_MIN:
            a=m.raw_concept_score(pt[t],int(yt[t]),q0,c0); b=m.raw_concept_score(pr[t],int(yr[t]),q0,c0); sc1,sc2=m.clipped_score(a,clips['C']),m.clipped_score(b,clips['C'])
        else: sc1=sc2=0.0
        dv={'X':float(np.clip((sx1-sx2)/2,-1,1)),'L':float(np.clip((sl1-sl2)/2,-1,1)),'C':float(np.clip((sc1-sc2)/2,-1,1))}
        gate=maxlog['X']<m.LABEL_X_GATE_LOGE
        ex=m.update_capital(lp['X'],lm['X'],dv['X']); maxlog['X']=max(maxlog['X'],ex)
        if 'X' not in crossing and ex>=line: crossing['X']=t+1
        if gate:
            el=m.update_label_capital(lp['L'],lm['L'],dv['L']); maxlog['L']=max(maxlog['L'],el)
            if 'L' not in crossing and el>=line: crossing['L']=t+1
        if r[t]:
            ec=m.update_concept_capital(lp['C'],lm['C'],dv['C']); maxlog['C']=max(maxlog['C'],ec)
            if 'C' not in crossing and ec>=line: crossing['C']=t+1
        ph.append(pt[t]);rh.append(int(r[t]));yh.append(int(yt[t])); qc=m.estimate_q_em(qc,np.asarray(ph),np.asarray(rh),np.asarray(yh))
        if r[t]: lab.append(int(yt[t])); conf=m.update_confusion(conf,pt[t],int(yt[t]))
    first=min(crossing.values()) if crossing else None; pre=bool(first is not None and first-1<T0)
    if cond=='null': det=first is not None; name=''
    elif pre: det=False; name=''
    else:
        ks=sorted(k for k,v in crossing.items() if v-1>=T0); det=bool(ks); name=ks[0] if len(ks)==1 else ('multiple_witnesses' if len(ks)>1 else '')
    delay=np.nan
    if cond!='null' and det: delay=min(v for v in crossing.values() if v-1>=T0)-(T0+1)
    return {'seed':seed,'condition':cond,'prechange_alarm':int(pre),'detected':int(det),'horizon_name':name,'delay':delay,**{f'max_log_{k}':v for k,v in maxlog.items()}}

def _init(fixed,clips):
    global _FIXED,_CLIPS; _FIXED=fixed; _CLIPS=clips; patch(fixed)
def _job(arg): return monitor(arg[0],arg[1],_FIXED,_CLIPS)

def main():
    fixed=setup(); clips={'X':0.027500697088122618,'L':0.8697861725514102,'C':2.3058074279735443}; print('clips',clips,flush=True)
    jobs=[(s,'null') for s in NULL_SEEDS]+[(s,c) for c in ('covariate','label','concept') for s in SHIFT_SEEDS]
    with ProcessPoolExecutor(max_workers=min(6,os.cpu_count() or 1),initializer=_init,initargs=(fixed,clips)) as ex: rows=list(ex.map(_job,jobs,chunksize=2))
    df=pd.DataFrame(rows); df.to_csv(OUT/'digits_benchmark_results.csv',index=False)
    lines=[f"Digits: n={len(fixed[7]) + len(fixed[0])}, d={fixed[0].shape[1]}, K={len(fixed[8])}, label_rate={LABEL_RATE}",f"clips X={clips['X']:.6g} L={clips['L']:.6g} C={clips['C']:.6g}"]
    for cond in ('null','covariate','label','concept'):
        g=df[df.condition==cond]
        if cond=='null': lines.append(f"null alarms={int(g.detected.sum())}/{len(g)}")
        else:
            gd=g[g.detected==1]; exp={'covariate':'X','label':'L','concept':'C'}[cond]; correct=int((gd.horizon_name==exp).sum()); multi=int((gd.horizon_name=='multiple_witnesses').sum()); med=gd.delay.median() if len(gd) else np.nan
            lines.append(f"{cond}: pre={int(g.prechange_alarm.sum())} detected={int(g.detected.sum())}/{len(g)} correct={correct} multiple={multi} median_delay={med}")
    text='\n'.join(lines)+'\n'; (OUT/'digits_benchmark_summary.txt').write_text(text); print(text,end='')
if __name__=='__main__': main()
