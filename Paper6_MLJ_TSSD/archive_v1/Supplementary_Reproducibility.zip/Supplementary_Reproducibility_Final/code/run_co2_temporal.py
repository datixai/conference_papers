#!/usr/bin/env python3
from __future__ import annotations
import math
from pathlib import Path
import numpy as np,pandas as pd
import statsmodels.api as sm
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import pairwise_distances, log_loss, accuracy_score
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import run_no_shift as m
OUT=HERE
ALPHA=.05; TH=math.log(60.0); LABEL_RATE=.05; T=600; BUFFER=50

def make_data():
    s=sm.datasets.co2.load_pandas().data['co2'].interpolate().bfill().ffill()
    df=pd.DataFrame({'co2':s})
    for lag in [1,2,4,13]: df[f'lag{lag}']=s.shift(lag)
    df['d1']=s.diff(); df['d4']=s-s.shift(4); df['ma4']=s.rolling(4).mean(); df['ma13']=s.rolling(13).mean()
    week=np.arange(len(df))%52
    df['sin52']=np.sin(2*np.pi*week/52); df['cos52']=np.cos(2*np.pi*week/52)
    df['y']=(s.shift(-1)>s).astype(float)
    df=df.dropna().copy(); df['y']=df.y.astype(int)
    X=df[['lag1','lag2','lag4','lag13','d1','d4','ma4','ma13','sin52','cos52']].to_numpy(float); y=df.y.to_numpy(int)
    dates=df.index.to_numpy()
    return X,y,dates

def setup():
    X,y,dates=make_data(); n=len(y)
    fit=np.arange(0,800); pool=np.arange(800,1200); tgt=np.arange(1200,1200+T)
    sc=StandardScaler().fit(X[fit]); xf=sc.transform(X[fit]); xp=sc.transform(X[pool]); xt=sc.transform(X[tgt]); yf=y[fit]; yp=y[pool]; yt=y[tgt]
    model=LogisticRegression(max_iter=2000,random_state=2026).fit(xf,yf)
    pi=np.bincount(yf,minlength=2).astype(float);pi/=pi.sum();
    m.K=2;m.D=xf.shape[1];m.PI=pi;m.N_FIT=len(xf);m.T=T;m.LABEL_RATE=LABEL_RATE;m.KERNEL_BUFFER=BUFFER
    jj=np.random.default_rng(2026).choice(len(xf),size=min(600,len(xf)),replace=False); dist=pairwise_distances(xf[jj]);tri=dist[np.triu_indices(len(jj),1)];bw=float(np.median(tri))
    pf=model.predict_proba(xf); vf=pf[:,:1]/pi[:1]-1;g=(vf.T@vf)/len(xf);ginv=np.linalg.pinv(g+1e-8*np.eye(1));mv=vf.mean(0)
    return xf,xp,yp,xt,yt,dates[tgt],model,bw,vf,ginv,mv,pi

def source_stream(seed,fixed):
    xf,xp,yp,xt,yt,dates,model,bw,vf,ginv,mv,pi=fixed; rng=np.random.default_rng(seed)
    it=rng.integers(0,len(xp),size=T); ir=rng.integers(0,len(xp),size=T)
    return xp[it],yp[it],xp[ir],yp[ir]

def raw_scores(seed,fixed):
    xf,xp,yp,xt0,yt0,dates,model,bw,vf,ginv,mv,pi=fixed; xa,ya,xr,yr=source_stream(seed,fixed);r=np.random.default_rng(seed+1).binomial(1,LABEL_RATE,size=T)
    pa,pr=model.predict_proba(xa),model.predict_proba(xr);sk,sv,km=m.build_stream_kernel_cache(xa,xr,xf,bw,vf)
    q=pi.copy();conf=m.empty_confusion();ph=[];rh=[];yh=[];lab=[]; vals={k:[] for k in 'XLC'}
    for t in range(T):
      q0=q.copy();c0=conf.copy();a,b=m.covariate_raw_pair(t,xa,xr,pa,pr,xf,bw,vf,ginv,mv,sk,sv,km);vals['X'] += [abs(a),abs(b)]
      a=m.raw_label_score(pa[t],int(r[t]),int(ya[t]),q0);b=m.raw_label_score(pr[t],int(r[t]),int(yr[t]),q0);vals['L'] += [abs(a),abs(b)]
      if r[t] and len(lab)>=m.M_MIN:
       a=m.raw_concept_score(pa[t],int(ya[t]),q0,c0);b=m.raw_concept_score(pr[t],int(yr[t]),q0,c0);vals['C'] += [abs(a),abs(b)]
      ph.append(pa[t]);rh.append(int(r[t]));yh.append(int(ya[t]));q=m.estimate_q_em(q,np.asarray(ph),np.asarray(rh),np.asarray(yh))
      if r[t]:lab.append(int(ya[t]));conf=m.update_confusion(conf,pa[t],int(ya[t]))
    return vals

def main():
    fixed=setup(); pools={k:[] for k in 'XLC'}
    for seed in range(9100,9105):
      v=raw_scores(seed,fixed)
      for k in pools:pools[k].extend(v[k])
    clips={k:float(np.quantile(v,.95)) for k,v in pools.items()}
    xf,xp,yp,xt,yt,dates,model,bw,vf,ginv,mv,pi=fixed; rng=np.random.default_rng(20261007); ir=rng.integers(0,len(xp),size=T);xr,yr=xp[ir],yp[ir];r=rng.binomial(1,LABEL_RATE,size=T)
    pt,pr=model.predict_proba(xt),model.predict_proba(xr);sk,sv,km=m.build_stream_kernel_cache(xt,xr,xf,bw,vf)
    q=pi.copy();conf=m.empty_confusion();ph=[];rh=[];yh=[];lab=[]
    lp={'X':np.zeros(2),'L':np.zeros(len(m.HOEFFDING_LAMBDAS))};lm={k:np.zeros_like(v) for k,v in lp.items()};cp=cm=0.;maxe={'X':0.,'L':0.,'C':0.};cross={}
    for t in range(T):
      q0=q.copy();c0=conf.copy();a,b=m.covariate_raw_pair(t,xt,xr,pt,pr,xf,bw,vf,ginv,mv,sk,sv,km);dx=(m.clipped_score(a,clips['X'])-m.clipped_score(b,clips['X']))/2
      a=m.raw_label_score(pt[t],int(r[t]),int(yt[t]),q0);b=m.raw_label_score(pr[t],int(r[t]),int(yr[t]),q0);dl=(m.clipped_score(a,clips['L'])-m.clipped_score(b,clips['L']))/2
      ex=m.update_capital(lp['X'],lm['X'],float(np.clip(dx,-1,1)));maxe['X']=max(maxe['X'],ex)
      if 'X' not in cross and ex>=TH:cross['X']=t
      if maxe['X']<m.LABEL_X_GATE_LOGE:
       el=m.update_label_capital(lp['L'],lm['L'],float(np.clip(dl,-1,1)));maxe['L']=max(maxe['L'],el)
       if 'L' not in cross and el>=TH:cross['L']=t
      if r[t] and len(lab)>=m.M_MIN:
       a=m.raw_concept_score(pt[t],int(yt[t]),q0,c0);b=m.raw_concept_score(pr[t],int(yr[t]),q0,c0);dc=float(np.clip((m.clipped_score(a,clips['C'])-m.clipped_score(b,clips['C']))/2,-1,1))
       cp += -np.inf if dc<=-1 else math.log1p(dc);cm += -np.inf if -dc<=-1 else math.log1p(-dc);ec=float(np.logaddexp(cp,cm)-math.log(2));maxe['C']=max(maxe['C'],ec)
       if 'C' not in cross and ec>=TH:cross['C']=t
      ph.append(pt[t]);rh.append(int(r[t]));yh.append(int(yt[t]));q=m.estimate_q_em(q,np.asarray(ph),np.asarray(rh),np.asarray(yh))
      if r[t]:lab.append(int(yt[t]));conf=m.update_confusion(conf,pt[t],int(yt[t]))
    pred=(pt[:,1]>=.5).astype(int); early=slice(0,200);late=slice(400,600)
    res={
      'n_total_series':len(make_data()[1]),'monitor_n':T,'monitor_start':str(pd.Timestamp(dates[0]).date()),'monitor_end':str(pd.Timestamp(dates[-1]).date()),'label_rate':LABEL_RATE,'revealed_labels':int(r.sum()),
      'clip_X':clips['X'],'clip_L':clips['L'],'clip_C':clips['C'],
      'cross_X_index':cross.get('X',np.nan),'cross_X_date':str(pd.Timestamp(dates[cross['X']]).date()) if 'X' in cross else '',
      'cross_L_index':cross.get('L',np.nan),'cross_L_date':str(pd.Timestamp(dates[cross['L']]).date()) if 'L' in cross else '',
      'cross_C_index':cross.get('C',np.nan),'cross_C_date':str(pd.Timestamp(dates[cross['C']]).date()) if 'C' in cross else '',
      'max_log_X':maxe['X'],'max_log_L':maxe['L'],'max_log_C':maxe['C'],
      'accuracy_first200':accuracy_score(yt[early],pred[early]),'accuracy_last200':accuracy_score(yt[late],pred[late]),
      'logloss_first200':log_loss(yt[early],pt[early],labels=[0,1]),'logloss_last200':log_loss(yt[late],pt[late],labels=[0,1])
    }
    pd.DataFrame([res]).to_csv(OUT/'co2_temporal_results.csv',index=False);print(pd.Series(res).to_string())
if __name__=='__main__':main()
