#!/usr/bin/env python3
"""Shift study for TSSD. Uses the same monitor as run_no_shift.py.

Change time t0 = 200 (0-based index). Before t0 the stream is the source law.
Seeds 1..N are independent of the 200-run null file.

Conditions
- covariate: inputs move by a fixed vector; labels are redrawn from the original posterior.
- label: class shares become (0.70, 0.20, 0.10); class-conditional inputs stay the same.
- concept: inputs stay on the source marginal; the label is cycled by one class.
- covariate_concept: the covariate move and the label cycle are applied together.
- covariate_label: class shares become (0.70, 0.20, 0.10) and every class cloud is shifted by the same vector. The recorded label is the class that generated the input.
- label_concept: the new class shares and the label cycle are applied together.
"""
from __future__ import annotations

import math
import os
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_HERE = Path(__file__).resolve().parent
for _candidate in (_HERE, _HERE.parent, Path(r"C:\Users\PMLS\Desktop\PPR format journal")):
    if (_candidate / "run_no_shift.py").exists():
        sys.path.insert(0, str(_candidate))
        break
import run_no_shift as m

T0 = 200
SHIFT = np.full(m.D, 2.0)
LABEL_Q = np.array([0.70, 0.20, 0.10])
# (name, label rate). The 0.05 rate matches the null study. The 0.20 rate is a
# prespecified sensitivity for streams that depend on labels.
CONDITIONS = [
    ("covariate", 0.05),
    ("covariate_mild", 0.05),
    ("label", 0.05),
    ("concept", 0.05),
    ("covariate_concept", 0.05),
    ("covariate_label", 0.05),
    ("label_concept", 0.05),
    ("label", 0.20),
    ("concept", 0.20),
    ("covariate_hard", 0.05),
]
TRUE_WITNESS = {
    "covariate": "X",
    "covariate_mild": "X",
    "covariate_hard": "X",
    "label": "L",
    "concept": "C",
}
OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)


def bayes_labels(rng, x, means):
    logits = x @ means.T - 0.5 * np.sum(means * means, axis=1)
    post = m.softmax(logits)
    # multinomial draw per row
    u = rng.random(len(x))
    cdf = np.cumsum(post, axis=1)
    return (u[:, None] > cdf).sum(axis=1).astype(int)


def make_target(rng, means, condition):
    x = np.zeros((m.T, m.D))
    y = np.zeros(m.T, dtype=int)
    x[:T0], y[:T0] = m.draw_pairs(rng, T0, means)
    n = m.T - T0
    if condition in ("covariate", "covariate_mild", "covariate_hard"):
        y_lat = rng.choice(m.K, size=n, p=m.PI)
        scale = {"covariate": 1.0, "covariate_mild": 0.5, "covariate_hard": 0.25}[condition]
        x_post = means[y_lat] + scale * SHIFT + rng.normal(size=(n, m.D))
        x[T0:] = x_post
        y[T0:] = bayes_labels(rng, x_post, means)
    elif condition == "label":
        y_post = rng.choice(m.K, size=n, p=LABEL_Q)
        x[T0:] = means[y_post] + rng.normal(size=(n, m.D))
        y[T0:] = y_post
    elif condition == "concept":
        y_lat = rng.choice(m.K, size=n, p=m.PI)
        x[T0:] = means[y_lat] + rng.normal(size=(n, m.D))
        y[T0:] = (y_lat + 1) % m.K
    elif condition == "covariate_concept":
        y_lat = rng.choice(m.K, size=n, p=m.PI)
        x_post = means[y_lat] + SHIFT + rng.normal(size=(n, m.D))
        x[T0:] = x_post
        y[T0:] = (bayes_labels(rng, x_post, means) + 1) % m.K
    elif condition == "covariate_label":
        y_post = rng.choice(m.K, size=n, p=LABEL_Q)
        x[T0:] = means[y_post] + SHIFT + rng.normal(size=(n, m.D))
        y[T0:] = y_post
    elif condition == "label_concept":
        y_lat = rng.choice(m.K, size=n, p=LABEL_Q)
        x[T0:] = means[y_lat] + rng.normal(size=(n, m.D))
        y[T0:] = (y_lat + 1) % m.K
    else:
        raise ValueError(condition)
    return x, y


def raw_mmd_pair(t, k_mon, horizon):
    if t == 0:
        return 0.0, 0.0
    start = max(0, t - m.KERNEL_BUFFER)
    h_tgt = float(k_mon[t, start:t].mean() - k_mon[t, horizon + start : horizon + t].mean())
    ridx = horizon + t
    h_ref = float(k_mon[ridx, start:t].mean() - k_mon[ridx, horizon + start : horizon + t].mean())
    return h_tgt, h_ref


def first_cross_after(times_and_keys, t0):
    """times are 1-based. Return (time or None, key or 'multiple_witnesses' or None)."""
    post = [(tm, key) for tm, key in times_and_keys if tm - 1 >= t0]
    if not post:
        return None, None
    earliest = min(tm for tm, _ in post)
    keys = sorted({key for tm, key in post if tm == earliest})
    if len(keys) == 1:
        return earliest, keys[0]
    return earliest, "multiple_witnesses"


def monitor_one(seed, condition, rate, fixed):
    means, x_fit, model, bandwidth, v_fit, g_inv, mean_v = fixed
    cond_index = CONDITIONS.index((condition, rate)) + 1
    rng = np.random.default_rng(seed + 10007 * cond_index)
    x_tgt, y_tgt = make_target(rng, means, condition)
    x_ref, y_ref = m.draw_pairs(rng, m.T, means)
    r = rng.binomial(1, rate, size=m.T).astype(int)

    p_tgt = model.predict_proba(x_tgt)
    p_ref = model.predict_proba(x_ref)
    src_kernel_mean, src_v_kernel_mean, k_mon = m.build_stream_kernel_cache(
        x_tgt, x_ref, x_fit, bandwidth, v_fit
    )

    q_current = m.PI.copy()
    confusion_current = m.empty_confusion()
    probs_hist, r_hist, y_hist = [], [], []
    labeled_y = []

    log_plus = {
        "X": np.zeros(len(m.CAPITAL_LAMBDAS)),
        "L": np.zeros(len(m.HOEFFDING_LAMBDAS)),
        "C": np.zeros(len(m.CONCEPT_LAMBDAS)),
    }
    log_minus = {key: np.zeros_like(val) for key, val in log_plus.items()}
    base_plus = {
        "MMD": np.zeros(len(m.CAPITAL_LAMBDAS)),
        "LAB": np.zeros(len(m.HOEFFDING_LAMBDAS)),
        "CON": np.zeros(len(m.CAPITAL_LAMBDAS)),
    }
    base_minus = {key: np.zeros_like(val) for key, val in base_plus.items()}
    cross_time = {}
    base_time = {}
    base_time_matched = {}
    log_threshold = math.log(1.0 / m.ALPHA_K)
    base_threshold = math.log(1.0 / m.ALPHA)
    max_log = {"X": 0.0, "L": 0.0, "C": 0.0}
    ll_sum = {"frozen": 0.0, "label": 0.0, "concept": 0.0, "policy": 0.0}
    n_post_labels = 0
    n_policy = 0
    n_abstain = 0
    crossed_running = set()

    for t in range(m.T):
        q_for_t = q_current.copy()
        confusion_for_t = confusion_current.copy()
        rx_tgt, rx_ref = m.covariate_raw_pair(
            t, x_tgt, x_ref, p_tgt, p_ref, x_fit, bandwidth, v_fit, g_inv, mean_v,
            src_kernel_mean, src_v_kernel_mean, k_mon,
        )
        sx_tgt = m.clipped_score(rx_tgt, m.SOURCE_CLIPS["X"])
        sx_ref = m.clipped_score(rx_ref, m.SOURCE_CLIPS["X"])
        rl_tgt = m.raw_label_score(p_tgt[t], int(r[t]), int(y_tgt[t]), q_for_t)
        rl_ref = m.raw_label_score(p_ref[t], int(r[t]), int(y_ref[t]), q_for_t)
        sl_tgt = m.clipped_score(rl_tgt, m.SOURCE_CLIPS["L"])
        sl_ref = m.clipped_score(rl_ref, m.SOURCE_CLIPS["L"])
        if r[t] == 1 and len(labeled_y) >= m.M_MIN:
            rc_tgt = m.raw_concept_score(p_tgt[t], int(y_tgt[t]), q_for_t, confusion_for_t)
            rc_ref = m.raw_concept_score(p_ref[t], int(y_ref[t]), q_for_t, confusion_for_t)
            sc_tgt = m.clipped_score(rc_tgt, m.SOURCE_CLIPS["C"])
            sc_ref = m.clipped_score(rc_ref, m.SOURCE_CLIPS["C"])
        else:
            sc_tgt = sc_ref = 0.0

        hm_tgt, hm_ref = raw_mmd_pair(t, k_mon, m.T)
        sm_tgt = m.clipped_score(hm_tgt, m.SOURCE_CLIPS["X"])
        sm_ref = m.clipped_score(hm_ref, m.SOURCE_CLIPS["X"])

        dvals = {
            "X": float(np.clip((sx_tgt - sx_ref) / 2.0, -1, 1)),
            "L": float(np.clip((sl_tgt - sl_ref) / 2.0, -1, 1)),
            "C": float(np.clip((sc_tgt - sc_ref) / 2.0, -1, 1)),
            "MMD": float(np.clip((sm_tgt - sm_ref) / 2.0, -1, 1)),
        }

        label_gate_open = max_log["X"] < m.LABEL_X_GATE_LOGE
        log_e = m.update_capital(log_plus["X"], log_minus["X"], dvals["X"])
        max_log["X"] = max(max_log["X"], log_e)
        if "X" not in cross_time and log_e >= log_threshold:
            cross_time["X"] = t + 1; crossed_running.add("X")
        if label_gate_open:
            log_e = m.update_label_capital(log_plus["L"], log_minus["L"], dvals["L"])
            max_log["L"] = max(max_log["L"], log_e)
            if "L" not in cross_time and log_e >= log_threshold:
                cross_time["L"] = t + 1; crossed_running.add("L")
        if r[t] == 1:
            log_e = m.update_concept_capital(log_plus["C"], log_minus["C"], dvals["C"])
            max_log["C"] = max(max_log["C"], log_e)
            if "C" not in cross_time and log_e >= log_threshold:
                cross_time["C"] = t + 1
                crossed_running.add("C")

        # Baselines use the full alpha budget and a single stream.
        base_map = {"MMD": dvals["MMD"], "LAB": dvals["L"], "CON": dvals["C"]}
        for bkey, dval in base_map.items():
            if bkey == "CON" and r[t] != 1:
                continue
            if bkey == "LAB":
                log_b = m.update_hoeffding(base_plus[bkey], base_minus[bkey], dval)
            else:
                log_b = m.update_capital(base_plus[bkey], base_minus[bkey], dval)
            if bkey not in base_time and log_b >= base_threshold:
                base_time[bkey] = t + 1
            if bkey not in base_time_matched and log_b >= log_threshold:
                base_time_matched[bkey] = t + 1

        if r[t] == 1 and t >= T0:
            yy = int(y_tgt[t])
            prob = p_tgt[t]
            ll_sum["frozen"] += -math.log(max(float(prob[yy]), m.LOG_FLOOR))
            weighted = (q_for_t / m.PI) * prob
            eta = weighted / max(float(weighted.sum()), m.LOG_FLOOR)
            ll_sum["label"] += -math.log(max(float(eta[yy]), m.LOG_FLOOR))
            alt = m.concept_distribution(prob, confusion_for_t)
            ll_sum["concept"] += -math.log(max(float(alt[yy]), m.LOG_FLOOR))
            n_post_labels += 1
            # Current name from crossings so far. Abstain when two witnesses have crossed.
            if crossed_running == {"L"}:
                chosen = eta
            elif crossed_running == {"C"}:
                chosen = alt
            elif len(crossed_running) >= 2:
                chosen = None
            else:
                chosen = prob
            if chosen is None:
                n_abstain += 1
            else:
                ll_sum["policy"] += -math.log(max(float(chosen[yy]), m.LOG_FLOOR))
                n_policy += 1

        probs_hist.append(p_tgt[t].copy())
        r_hist.append(int(r[t]))
        y_hist.append(int(y_tgt[t]))
        q_current = m.estimate_q_em(
            q_current, np.asarray(probs_hist), np.asarray(r_hist, dtype=int), np.asarray(y_hist, dtype=int)
        )
        if r[t] == 1:
            labeled_y.append(int(y_tgt[t]))
            confusion_current = m.update_confusion(confusion_current, p_tgt[t], int(y_tgt[t]))

    # A stream that has already crossed before the simulated change has already
    # produced an operational alarm.  It is therefore not recycled, using oracle
    # knowledge of T0, as a later post-change detection.
    pre = [tm for tm in cross_time.values() if tm - 1 < T0]
    if pre:
        alarm_time, first_name = None, None
        horizon_name = ""
    else:
        alarm_time, first_name = first_cross_after([(tm, key) for key, tm in cross_time.items()], T0)
        active_keys = sorted(key for key, tm in cross_time.items() if tm - 1 >= T0)
        if len(active_keys) == 0:
            horizon_name = ""
        elif len(active_keys) == 1:
            horizon_name = active_keys[0]
        else:
            horizon_name = "multiple_witnesses"
    true = TRUE_WITNESS.get(condition)
    if true is None:
        correct = int(horizon_name == "multiple_witnesses")
    else:
        correct = int(horizon_name == true)

    def post_time(store):
        tm = store.get("MMD") if False else None
        return None

    def after(store, key):
        tm = store.get(key)
        if tm is None or tm - 1 < T0:
            return None
        return tm

    return {
        "condition": condition,
        "label_rate": rate,
        "seed": seed,
        "prechange_alarm": int(len(pre) > 0),
        "detect_time": alarm_time if alarm_time is not None else np.nan,
        "detected": int(alarm_time is not None),
        "first_name": first_name if first_name else "",
        "horizon_name": horizon_name,
        "final_name": horizon_name,
        "correct_name": correct,
        "named_multiple_witnesses": int(horizon_name == "multiple_witnesses"),
        "max_log_X": max_log["X"],
        "max_log_L": max_log["L"],
        "max_log_C": max_log["C"],
        "mmd_detect_time": after(base_time, "MMD") if after(base_time, "MMD") else np.nan,
        "mmd_detected": int(after(base_time, "MMD") is not None),
        "mmd_prechange": int(base_time.get("MMD", 10**9) - 1 < T0) if "MMD" in base_time else 0,
        "lab_detected": int(after(base_time, "LAB") is not None),
        "lab_detect_time": after(base_time, "LAB") if after(base_time, "LAB") else np.nan,
        "con_detected": int(after(base_time, "CON") is not None),
        "con_detect_time": after(base_time, "CON") if after(base_time, "CON") else np.nan,
        "mmd_matched": int(after(base_time_matched, "MMD") is not None),
        "lab_matched": int(after(base_time_matched, "LAB") is not None),
        "con_matched": int(after(base_time_matched, "CON") is not None),
        "n_post_labels": n_post_labels,
        "ll_frozen": ll_sum["frozen"] / n_post_labels if n_post_labels else np.nan,
        "ll_label": ll_sum["label"] / n_post_labels if n_post_labels else np.nan,
        "ll_concept": ll_sum["concept"] / n_post_labels if n_post_labels else np.nan,
        "ll_policy": ll_sum["policy"] / n_policy if n_policy else np.nan,
        "abstain_rate": n_abstain / n_post_labels if n_post_labels else np.nan,
    }


_FIXED = None


def _init(fixed):
    global _FIXED
    _FIXED = fixed


def _job(job):
    seed, condition, rate = job
    return monitor_one(seed, condition, rate, _FIXED)


def summarize(df):
    lines = []
    for (cond, rate), g in df.groupby(["condition", "label_rate"], sort=False):
        n = len(g)
        det = int(g.detected.sum())
        pre = int(g.prechange_alarm.sum())
        named = g[g.detected == 1]
        correct = int(named.correct_name.sum()) if len(named) else 0
        delays = (named.detect_time - (T0 + 1)).dropna()
        med = float(delays.median()) if len(delays) else float("nan")
        lines.append(
            f"{cond} rate={rate}: n={n} prechange={pre} detected={det} "
            f"correct_among_alarms={correct} median_delay={med} "
            f"multiple={int(g.named_multiple_witnesses.sum())} "
            f"mmd={int(g.mmd_detected.sum())} mmd60={int(g.mmd_matched.sum())} "
            f"lab={int(g.lab_detected.sum())} lab60={int(g.lab_matched.sum())} "
            f"con={int(g.con_detected.sum())} con60={int(g.con_matched.sum())} "
            f"llF={g.ll_frozen.median():.3f} llL={g.ll_label.median():.3f} llC={g.ll_concept.median():.3f} "
            f"llP={g.ll_policy.median():.3f} abs={g.abstain_rate.median():.3f} "
            f"med_maxX={g.max_log_X.median():.3f} med_maxL={g.max_log_L.median():.3f} "
            f"med_maxC={float(np.nanmedian(g.max_log_C.replace(-np.inf, np.nan))):.3f}"
        )
    return "\n".join(lines)


def main():
    n_seeds = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    seeds = list(range(1, n_seeds + 1))
    fixed = m.prepare_fixed_source()
    jobs = [(s, c, rate) for c, rate in CONDITIONS for s in seeds]
    workers = min(4, os.cpu_count() or 1)
    with ProcessPoolExecutor(max_workers=workers, initializer=_init, initargs=(fixed,)) as pool:
        rows = list(pool.map(_job, jobs, chunksize=1))
    df = pd.DataFrame(rows)
    csv_path = OUT / "shift_results.csv"
    df.to_csv(csv_path, index=False)
    text = summarize(df)
    (OUT / "shift_summary.txt").write_text(text + "\n", encoding="utf-8")
    print(text)
    print("WROTE", csv_path)


if __name__ == "__main__":
    main()
