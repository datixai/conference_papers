#!/usr/bin/env python3
"""
TSSD no-shift false-alarm check, v3.

This script revises only the no-shift simulation. It does not edit the manuscript,
fill manuscript tables, or run shift-detection/power experiments.

Fixed experiment inherited from v2:
- d = 10, K = 3, class prior = (1/3, 1/3, 1/3).
- Class means are generated once with NumPy seed 0 and then frozen.
- X | Y=y ~ Normal(mu_y, I_10).
- One multinomial logistic-regression source model is trained once on 2,000 labeled
  source-fitting draws (fitting seed 2026) and then frozen.
- T = 400, label-probe rate = 0.05, alpha = 0.05, seeds = 1, ..., 200.
- Every monitoring step uses a fresh target draw and a fresh source-reference draw.
- The covariate witness uses the last 50 previous target/reference inputs.
- Clip constants are the empirical 95th percentiles of the absolute raw witness scores
  on disjoint source-only calibration seeds 9000 through 9019, reproduced by calibrate_clips.py:
    c_X = 0.030549503301877223
    c_L = 0.30610870092768355
    c_C = 1.101259429554347

Betting revision:
- Covariate: equal mixture of capital processes with lambda in {0.5, 1}. Concept: two-sided capital process with fixed lambda = 1, selected before the final confirmatory rerun from a disjoint development analysis.
  For each lambda, maintain positive and negative processes using
  (1 + lambda * D) and (1 - lambda * D). Evidence is the arithmetic mean of
  those four processes. A zero increment leaves every capital process unchanged.
- Label: equal mixture of bounded capital processes with lambda in
  {0.01, 0.05, 0.10, 0.25, 0.50, 1}, both signs. The label process is
  predictably gated using only past covariate evidence: it updates while the
  past maximum covariate log-evidence is below 2.0 and otherwise uses an
  identity update.
- Covariate evidence updates at every monitoring time; label evidence updates
  only while the predictable gate is open.
- Concept evidence updates only when R_t = 1. If R_t = 0, its evidence is left
  exactly unchanged.
- alpha_k = alpha / 3 and a witness crosses when log evidence reaches
  log(1 / alpha_k).

Outputs:
- tssd_false_alarm_results.csv: one row per seed.
- run_output.txt: exact summary lines printed by the script.

The default command runs seeds 1..200. Optional batch arguments are provided only
so the same fixed experiment can be executed in bounded compute environments.
"""

from __future__ import annotations

import argparse
import math
import os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import pairwise_distances

D = 10
K = 3
PI = np.full(K, 1.0 / K)
N_FIT = 2000
T = 400
LABEL_RATE = 0.05
ALPHA = 0.05
ALPHA_K = ALPHA / 3.0
ALL_SEEDS = list(range(1, 201))
EPS_Q = 1e-3
LOG_FLOOR = 1e-8
M_MIN = 5
EM_STEPS = 10
CONCEPT_DECAY = 0.85
CONCEPT_PRIOR = 1.0
RIDGE = 1e-8
KERNEL_BUFFER = 50
LABEL_X_GATE_LOGE = 2.0  # predictable label-bet gate based on past covariate evidence
# Covariate and concept use capital bets. D is in [-1, 1], so lambda in (0, 1]
# keeps 1 + lambda*D nonnegative. A zero increment multiplies wealth by 1.
# Label keeps the Hoeffding grid: a capital bet on that every-step score also
# crosses under a pure location shift. Both grids are fixed before evaluation.
CAPITAL_LAMBDAS = np.asarray([0.50, 1.00], dtype=float)
CONCEPT_LAMBDAS = np.asarray([1.00], dtype=float)
HOEFFDING_LAMBDAS = np.asarray([0.01, 0.05, 0.10, 0.25, 0.50, 1.00], dtype=float)
BET_LAMBDAS = HOEFFDING_LAMBDAS  # imported by older call sites; label witness only
SOURCE_CLIPS = {
    "X": 0.030549503301877223,
    "L": 0.30610870092768355,
    "C": 1.101259429554347,
    "MMD": 0.05851293885375384,
}

OUT_DIR = Path(__file__).resolve().parent
DEFAULT_CSV_PATH = OUT_DIR / "tssd_false_alarm_results.csv"
DEFAULT_OUTPUT_PATH = OUT_DIR / "run_output.txt"


def softmax(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z, dtype=float)
    z = z - np.max(z, axis=-1, keepdims=True)
    e = np.exp(z)
    return e / np.sum(e, axis=-1, keepdims=True)


def draw_pairs(rng: np.random.Generator, n: int, means: np.ndarray):
    y = rng.choice(K, size=n, p=PI)
    x = means[y] + rng.normal(size=(n, D))
    return x, y


def gaussian_kernel_matrix(a: np.ndarray, b: np.ndarray, bandwidth: float) -> np.ndarray:
    a2 = np.sum(a * a, axis=1)[:, None]
    b2 = np.sum(b * b, axis=1)[None, :]
    sq = np.maximum(a2 + b2 - 2.0 * (a @ b.T), 0.0)
    return np.exp(-sq / (2.0 * bandwidth * bandwidth))


def source_logits_from_proba(p: np.ndarray) -> np.ndarray:
    return np.log(np.clip(p, LOG_FLOOR, 1.0))


def restricted_simplex(q: np.ndarray) -> np.ndarray:
    q = np.maximum(np.asarray(q, dtype=float), EPS_Q)
    q = q / q.sum()
    if np.min(q) < EPS_Q:
        base = np.full(K, EPS_Q)
        remainder = 1.0 - K * EPS_Q
        positive = np.maximum(q - EPS_Q, 0.0)
        if positive.sum() == 0:
            return np.full(K, 1.0 / K)
        q = base + remainder * positive / positive.sum()
    return q


def estimate_q_em(q_start, probs_hist, r_hist, y_hist):
    if probs_hist.shape[0] == 0:
        return q_start.copy()
    q = restricted_simplex(q_start)
    unlabeled = r_hist == 0
    labeled = ~unlabeled
    for _ in range(EM_STEPS):
        counts = np.zeros(K, dtype=float)
        if np.any(unlabeled):
            p = probs_hist[unlabeled]
            weighted = p * (q / PI)[None, :]
            weighted /= np.clip(weighted.sum(axis=1, keepdims=True), LOG_FLOOR, None)
            counts += weighted.sum(axis=0)
        if np.any(labeled):
            counts += np.bincount(y_hist[labeled], minlength=K)
        q = restricted_simplex(counts / probs_hist.shape[0])
    return q


def empty_confusion() -> np.ndarray:
    """Add-one counts. Rows are source-model classes, columns are observed labels."""
    return np.full((K, K), CONCEPT_PRIOR, dtype=float)


def update_confusion(confusion: np.ndarray, prob: np.ndarray, y: int) -> np.ndarray:
    """Forget excess counts, then add the new labeled case. The prior is kept."""
    out = confusion.copy()
    excess = out - CONCEPT_PRIOR
    out = CONCEPT_DECAY * excess + CONCEPT_PRIOR
    out[:, int(y)] += np.asarray(prob, dtype=float)
    return out


def concept_distribution(prob: np.ndarray, confusion: np.ndarray) -> np.ndarray:
    row_sum = np.maximum(confusion.sum(axis=1, keepdims=True), LOG_FLOOR)
    remapped = (confusion / row_sum).T @ np.asarray(prob, dtype=float)
    total = float(remapped.sum())
    if total <= 0:
        return np.full(K, 1.0 / K)
    return remapped / total


def raw_label_score(prob: np.ndarray, r: int, y: int, q: np.ndarray) -> float:
    if r == 0:
        w = float(np.dot(q / PI, prob))
        return math.log(max(w, LOG_FLOOR))
    ratio = float(q[y] / PI[y])
    return math.log(max(ratio, LOG_FLOOR))


def raw_concept_score(prob: np.ndarray, y: int, q: np.ndarray, confusion: np.ndarray) -> float:
    alt = concept_distribution(prob, confusion)
    weighted = (q / PI) * np.asarray(prob, dtype=float)
    eta = weighted / max(float(weighted.sum()), LOG_FLOOR)
    return math.log(max(float(alt[y]), LOG_FLOOR)) - math.log(max(float(eta[y]), LOG_FLOOR))


def clipped_score(raw: float, clip: float) -> float:
    return float(np.clip(raw, -clip, clip) / clip)


def log_mixture_evidence(log_plus: np.ndarray, log_minus: np.ndarray) -> float:
    """Log of the equal arithmetic mean of the positive and negative processes."""
    terms = np.concatenate([log_plus, log_minus])
    return float(np.logaddexp.reduce(terms) - math.log(len(terms)))


def wilson_interval(k: int, n: int, z: float = 1.959963984540054):
    p = k / n
    den = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / den
    half = (z / den) * math.sqrt((p * (1.0 - p) / n) + z * z / (4.0 * n * n))
    return max(0.0, center - half), min(1.0, center + half)


def prepare_fixed_source():
    mean_rng = np.random.default_rng(0)
    means = mean_rng.normal(size=(K, D))

    fit_rng = np.random.default_rng(2026)
    x_fit, y_fit = draw_pairs(fit_rng, N_FIT, means)

    model = LogisticRegression(solver="lbfgs", max_iter=1000, random_state=2026)
    model.fit(x_fit, y_fit)

    dist = pairwise_distances(x_fit, metric="euclidean")
    tri = dist[np.triu_indices(N_FIT, k=1)]
    bandwidth = float(np.median(tri))
    del dist, tri

    p_fit = model.predict_proba(x_fit)
    v_fit = p_fit[:, : K - 1] / PI[: K - 1] - 1.0
    g_mat = (v_fit.T @ v_fit) / N_FIT
    g_inv = np.linalg.pinv(g_mat + RIDGE * np.eye(K - 1))
    mean_v = v_fit.mean(axis=0)

    return means, x_fit, model, bandwidth, v_fit, g_inv, mean_v


def covariate_raw_pair(
    t, x_tgt, x_ref, p_tgt, p_ref, x_fit, bandwidth, v_fit, g_inv, mean_v,
    src_kernel_mean, src_v_kernel_mean, k_mon,
):
    if t == 0:
        return 0.0, 0.0
    horizon = x_tgt.shape[0]
    start = max(0, t - KERNEL_BUFFER)
    tgt_hist_idx = slice(start, t)
    ref_hist_idx = slice(horizon + start, horizon + t)

    c_t = src_v_kernel_mean[tgt_hist_idx].mean(axis=0) - src_v_kernel_mean[ref_hist_idx].mean(axis=0)
    mean_h_source = float(src_kernel_mean[tgt_hist_idx].mean() - src_kernel_mean[ref_hist_idx].mean())
    b_t = mean_h_source - float(c_t @ g_inv @ mean_v)

    h_raw_tgt = float(k_mon[t, start:t].mean() - k_mon[t, horizon + start : horizon + t].mean())
    v_tgt = p_tgt[t, : K - 1] / PI[: K - 1] - 1.0
    h_perp_tgt = h_raw_tgt - float(c_t @ g_inv @ v_tgt) - b_t

    ridx = horizon + t
    h_raw_ref = float(k_mon[ridx, start:t].mean() - k_mon[ridx, horizon + start : horizon + t].mean())
    v_ref = p_ref[t, : K - 1] / PI[: K - 1] - 1.0
    h_perp_ref = h_raw_ref - float(c_t @ g_inv @ v_ref) - b_t
    return h_perp_tgt, h_perp_ref


def build_stream_kernel_cache(x_tgt, x_ref, x_fit, bandwidth, v_fit):
    x_mon = np.vstack([x_tgt, x_ref])
    k_src_mon = gaussian_kernel_matrix(x_fit, x_mon, bandwidth)
    src_kernel_mean = k_src_mon.mean(axis=0)
    src_v_kernel_mean = (k_src_mon.T @ v_fit) / N_FIT
    del k_src_mon
    k_mon = gaussian_kernel_matrix(x_mon, x_mon, bandwidth)
    return src_kernel_mean, src_v_kernel_mean, k_mon


def _log1p_wealth(increment: np.ndarray) -> np.ndarray:
    """log(1 + z) for z >= -1. Exact ruin (z = -1) is -inf, without a warning."""
    out = np.empty(increment.shape, dtype=float)
    ruined = increment <= -1.0
    out[ruined] = -np.inf
    safe = ~ruined
    out[safe] = np.log1p(increment[safe])
    return out


def update_capital(log_plus: np.ndarray, log_minus: np.ndarray, dval: float):
    """Multiply by 1 ± lambda D. Mean-zero D makes each factor a martingale increment."""
    log_plus += _log1p_wealth(CAPITAL_LAMBDAS * dval)
    log_minus += _log1p_wealth(-CAPITAL_LAMBDAS * dval)
    return log_mixture_evidence(log_plus, log_minus)



def update_concept_capital(log_plus: np.ndarray, log_minus: np.ndarray, dval: float):
    """Concept e-process with the power-optimized fixed lambda=1 two-sided capital mixture."""
    log_plus += _log1p_wealth(CONCEPT_LAMBDAS * dval)
    log_minus += _log1p_wealth(-CONCEPT_LAMBDAS * dval)
    return log_mixture_evidence(log_plus, log_minus)


def update_label_capital(log_plus: np.ndarray, log_minus: np.ndarray, dval: float):
    """Label e-process using the same bounded capital construction on the label lambda grid."""
    log_plus += _log1p_wealth(HOEFFDING_LAMBDAS * dval)
    log_minus += _log1p_wealth(-HOEFFDING_LAMBDAS * dval)
    return log_mixture_evidence(log_plus, log_minus)

def update_hoeffding(log_plus: np.ndarray, log_minus: np.ndarray, dval: float):
    penalty = (HOEFFDING_LAMBDAS * HOEFFDING_LAMBDAS) / 2.0
    log_plus += HOEFFDING_LAMBDAS * dval - penalty
    log_minus += -HOEFFDING_LAMBDAS * dval - penalty
    return log_mixture_evidence(log_plus, log_minus)


def update_mixture(log_plus: np.ndarray, log_minus: np.ndarray, dval: float):
    """Label witness and the label baseline. Hoeffding mixture."""
    return update_hoeffding(log_plus, log_minus, dval)


def run_seed(seed, means, x_fit, model, bandwidth, v_fit, g_inv, mean_v):
    rng = np.random.default_rng(seed)
    x_tgt, y_tgt = draw_pairs(rng, T, means)
    x_ref, y_ref = draw_pairs(rng, T, means)
    r = rng.binomial(1, LABEL_RATE, size=T).astype(int)

    p_tgt = model.predict_proba(x_tgt)
    p_ref = model.predict_proba(x_ref)
    src_kernel_mean, src_v_kernel_mean, k_mon = build_stream_kernel_cache(
        x_tgt, x_ref, x_fit, bandwidth, v_fit
    )

    q_current = PI.copy()
    confusion_current = empty_confusion()
    probs_hist, r_hist, y_hist = [], [], []
    labeled_y = []

    log_plus = {
        "X": np.zeros(len(CAPITAL_LAMBDAS)),
        "L": np.zeros(len(HOEFFDING_LAMBDAS)),
        "C": np.zeros(len(CONCEPT_LAMBDAS)),
    }
    log_minus = {key: np.zeros_like(val) for key, val in log_plus.items()}
    current_log_e = {"X": 0.0, "L": 0.0, "C": 0.0}
    crossed = {"X": False, "L": False, "C": False}
    max_abs_d = {"X": 0.0, "L": 0.0, "C": 0.0}
    max_log_e = {"X": 0.0, "L": 0.0, "C": 0.0}
    first_alarm_time = None
    log_threshold = math.log(1.0 / ALPHA_K)

    for t in range(T):
        q_for_t = q_current.copy()
        confusion_for_t = confusion_current.copy()

        rx_tgt, rx_ref = covariate_raw_pair(
            t, x_tgt, x_ref, p_tgt, p_ref, x_fit, bandwidth, v_fit, g_inv, mean_v,
            src_kernel_mean, src_v_kernel_mean, k_mon,
        )
        sx_tgt = clipped_score(rx_tgt, SOURCE_CLIPS["X"])
        sx_ref = clipped_score(rx_ref, SOURCE_CLIPS["X"])

        rl_tgt = raw_label_score(p_tgt[t], int(r[t]), int(y_tgt[t]), q_for_t)
        rl_ref = raw_label_score(p_ref[t], int(r[t]), int(y_ref[t]), q_for_t)
        sl_tgt = clipped_score(rl_tgt, SOURCE_CLIPS["L"])
        sl_ref = clipped_score(rl_ref, SOURCE_CLIPS["L"])

        if r[t] == 1 and len(labeled_y) >= M_MIN:
            rc_tgt = raw_concept_score(p_tgt[t], int(y_tgt[t]), q_for_t, confusion_for_t)
            rc_ref = raw_concept_score(p_ref[t], int(y_ref[t]), q_for_t, confusion_for_t)
            sc_tgt = clipped_score(rc_tgt, SOURCE_CLIPS["C"])
            sc_ref = clipped_score(rc_ref, SOURCE_CLIPS["C"])
        else:
            sc_tgt = 0.0
            sc_ref = 0.0

        dvals = {
            "X": float(np.clip((sx_tgt - sx_ref) / 2.0, -1.0, 1.0)),
            "L": float(np.clip((sl_tgt - sl_ref) / 2.0, -1.0, 1.0)),
            "C": float(np.clip((sc_tgt - sc_ref) / 2.0, -1.0, 1.0)),
        }

        # X updates every time.  The label capital is predictably gated by
        # covariate evidence available before observing the fresh pair at time t.
        label_gate_open = max_log_e["X"] < LABEL_X_GATE_LOGE
        dval = dvals["X"]
        max_abs_d["X"] = max(max_abs_d["X"], abs(dval))
        current_log_e["X"] = update_capital(log_plus["X"], log_minus["X"], dval)
        max_log_e["X"] = max(max_log_e["X"], current_log_e["X"])
        if (not crossed["X"]) and current_log_e["X"] >= log_threshold:
            crossed["X"] = True
            if first_alarm_time is None: first_alarm_time = t + 1

        dval = dvals["L"]
        max_abs_d["L"] = max(max_abs_d["L"], abs(dval))
        if label_gate_open:
            current_log_e["L"] = update_label_capital(log_plus["L"], log_minus["L"], dval)
        max_log_e["L"] = max(max_log_e["L"], current_log_e["L"])
        if (not crossed["L"]) and current_log_e["L"] >= log_threshold:
            crossed["L"] = True
            if first_alarm_time is None: first_alarm_time = t + 1

        # Concept evidence is exactly unchanged on unlabeled steps.
        max_abs_d["C"] = max(max_abs_d["C"], abs(dvals["C"]))
        if r[t] == 1:
            current_log_e["C"] = update_concept_capital(log_plus["C"], log_minus["C"], dvals["C"])
        max_log_e["C"] = max(max_log_e["C"], current_log_e["C"])
        if (not crossed["C"]) and current_log_e["C"] >= log_threshold:
            crossed["C"] = True
            if first_alarm_time is None:
                first_alarm_time = t + 1

        probs_hist.append(p_tgt[t].copy())
        r_hist.append(int(r[t]))
        y_hist.append(int(y_tgt[t]))
        q_current = estimate_q_em(
            q_current,
            np.asarray(probs_hist),
            np.asarray(r_hist, dtype=int),
            np.asarray(y_hist, dtype=int),
        )

        if r[t] == 1:
            labeled_y.append(int(y_tgt[t]))
            confusion_current = update_confusion(confusion_current, p_tgt[t], int(y_tgt[t]))

    alarm = bool(crossed["X"] or crossed["L"] or crossed["C"])
    return {
        "seed": seed,
        "alarm": int(alarm),
        "first_alarm_time": first_alarm_time,
        "crossed_X": int(crossed["X"]),
        "crossed_L": int(crossed["L"]),
        "crossed_C": int(crossed["C"]),
        "max_abs_D_X": max_abs_d["X"],
        "max_abs_D_L": max_abs_d["L"],
        "max_abs_D_C": max_abs_d["C"],
        "max_log_evidence_X": max_log_e["X"],
        "max_log_evidence_L": max_log_e["L"],
        "max_log_evidence_C": max_log_e["C"],
    }


_WORKER_FIXED = None


def _init_worker(worker_fixed):
    global _WORKER_FIXED
    _WORKER_FIXED = worker_fixed


def _run_seed_worker(seed):
    return run_seed(seed, *_WORKER_FIXED)


def summary_lines(df: pd.DataFrame) -> list[str]:
    df = df.sort_values("seed").reset_index(drop=True)
    n = len(df)
    alarms = int(df["alarm"].sum())
    rate = alarms / n
    lo, hi = wilson_interval(alarms, n)
    threshold = math.log(1.0 / ALPHA_K)

    lines = [
        f"number of seeds: {n}",
        f"horizon T: {T}",
        f"alpha: {ALPHA:.2f}",
        f"number of seeds with a false alarm: {alarms}",
        f"empirical false-alarm rate: {rate:.6f}",
        f"Wilson 95% interval: [{lo:.6f}, {hi:.6f}]",
    ]
    for key in ("X", "L", "C"):
        col = f"max_log_evidence_{key}"
        lines.append(f"median max log-evidence {key}: {df[col].median():.6f}")
        lines.append(f"maximum max log-evidence {key}: {df[col].max():.6f}")
        lines.append(f"seeds with max log-evidence {key} > 0: {int((df[col] > 0).sum())}")
        lines.append(f"seeds with max log-evidence {key} >= 1: {int((df[col] >= 1).sum())}")
    lines.append(f"alarm threshold log(1/alpha_k): {threshold:.6f}")
    return lines


def write_and_print_summary(df: pd.DataFrame, output_path: Path | None):
    lines = summary_lines(df)
    text = "\n".join(lines) + "\n"
    if output_path is not None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(text, encoding="utf-8")
    print(text, end="")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--start-seed", type=int, default=1)
    p.add_argument("--end-seed", type=int, default=200)
    p.add_argument("--csv", type=Path, default=DEFAULT_CSV_PATH)
    p.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_PATH)
    p.add_argument("--quiet", action="store_true")
    p.add_argument("--summarize-csv", type=Path, default=None)
    return p.parse_args()


def main():
    args = parse_args()

    if args.summarize_csv is not None:
        df = pd.read_csv(args.summarize_csv)
        expected = set(ALL_SEEDS)
        actual = set(int(s) for s in df["seed"].tolist())
        if actual != expected or len(df) != 200:
            raise RuntimeError("Summary CSV must contain exactly one row for every seed 1..200")
        write_and_print_summary(df, args.output)
        return

    if not (1 <= args.start_seed <= args.end_seed <= 200):
        raise ValueError("Seed range must lie within 1..200")
    seeds = list(range(args.start_seed, args.end_seed + 1))

    means, x_fit, model, bandwidth, v_fit, g_inv, mean_v = prepare_fixed_source()
    worker_fixed = (means, x_fit, model, bandwidth, v_fit, g_inv, mean_v)
    workers = min(4, os.cpu_count() or 1)
    with ProcessPoolExecutor(
        max_workers=workers, initializer=_init_worker, initargs=(worker_fixed,)
    ) as pool:
        rows = list(pool.map(_run_seed_worker, seeds, chunksize=5))

    df = pd.DataFrame(rows).sort_values("seed").reset_index(drop=True)
    args.csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.csv, index=False, na_rep="NA")

    if not args.quiet:
        write_and_print_summary(df, args.output)


if __name__ == "__main__":
    main()
