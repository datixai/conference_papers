# TSSD final reproducibility package

This archive accompanies the final Machine Learning journal manuscript.

## What changed in the closure rerun
- Concept e-process uses a fixed two-sided capital bet with lambda_C = 1.
- Primary 5% concept arm was rerun from the executable monitor: 127/200 valid detections after one pre-change alarm, median delay 150.
- Concept-label-budget sensitivity is included for 5%, 10%, and 20% label reveal.
- Digits was rerun with the same fixed concept bet: 21/50 concept detections/correct singleton diagnoses.
- A chronological Mauna Loa weekly CO2 case study is included via `run_co2_temporal.py`.
- `run_shift_study.py`, previously omitted from the supplementary ZIP despite being imported by the core runner, is now included.

## Main scripts
- `code/run_no_shift.py`: 200-stream global-null check.
- `code/run_shift_study.py`: controlled shift generator and full TSSD monitor.
- `code/run_core200_one.py`: one 200-replicate primary arm.
- `code/run_external_baselines.py`: BBSD-soft, classifier-CUSUM, Page-Hinkley comparison.
- `code/run_digits_benchmark.py`: 64-feature Digits stress test.
- `code/run_roschewitz_digits.py`: Roschewitz-style identification logic on Digits.
- `code/run_co2_temporal.py`: chronological Mauna Loa CO2 monitoring case study.

## Exact manuscript outputs
The `results/` directory contains the CSV/JSON/text files used for the final manuscript. `core200_results.csv` is the merged final 5% primary study. The concept arm was regenerated after the fixed lambda_C=1 revision.

## Reproduction notes
Run scripts from the `code/` directory. The controlled Gaussian study uses deterministic fixed seeds documented in source. The CO2 case study uses the public statsmodels weekly Mauna Loa dataset, so no external file download is required.

The theorem guarantees false-alarm control under the assumptions stated in the manuscript; empirical detection rates are not theorem guarantees.
